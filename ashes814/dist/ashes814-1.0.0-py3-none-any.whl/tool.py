import ashes814

ashes814.ashescool.run()

for i in range(10):
    print(i)