def run():

    print("I am really cool!")